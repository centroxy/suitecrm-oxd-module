<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$vardefs = array (
    'fields' =>
        array (
        ),
    'relationships' =>
        array (
        ),
);
?>
