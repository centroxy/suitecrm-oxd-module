<?php

$base_url  = @( $_SERVER["HTTPS"] != 'on' ) ? 'http://'.$_SERVER["SERVER_NAME"] :  'https://'.$_SERVER["SERVER_NAME"];

$db = DBManagerFactory::getInstance();

$query = "CREATE TABLE IF NOT EXISTS `gluu_table` (
  `gluu_action` varchar(255) NOT NULL,
  `gluu_value` longtext NOT NULL,
  UNIQUE(`gluu_action`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8";
;
$result = $db->query($query);
if($db->query("SELECT `gluu_value` FROM `gluu_table` WHERE `gluu_action` LIKE 'scopes'")){
    $get_scopes = json_encode(array("openid","profile","email","address","clientinfo","mobile_phone","phone"));
    $result = $db->query("INSERT INTO gluu_table (gluu_action, gluu_value) VALUES ('scopes','$get_scopes')");
}
if($db->query("SELECT `gluu_value` FROM `gluu_table` WHERE `gluu_action` LIKE 'custom_scripts'")){
    $custom_scripts = json_encode(array(
        array('name'=>'Google','image'=>'modules/Gluussos/GluuOxd_Openid/images/icons/google.png','value'=>'gplus'),
        array('name'=>'Basic','image'=>'modules/Gluussos/GluuOxd_Openid/images/icons/basic.png','value'=>'basic'),
        array('name'=>'Duo','image'=>'modules/Gluussos/GluuOxd_Openid/images/icons/duo.png','value'=>'duo'),
        array('name'=>'OxPush2','image'=>'modules/Gluussos/GluuOxd_Openid/images/icons/oxpush2.png','value'=>'oxpush2'),
        array('name'=>'U2F token','image'=>'modules/Gluussos/GluuOxd_Openid/images/icons/u2f.png','value'=>'u2f')
    ));
    $result = $db->query("INSERT INTO gluu_table (gluu_action, gluu_value) VALUES ('custom_scripts','$custom_scripts')");
}
if($db->query("SELECT `gluu_value` FROM `gluu_table` WHERE `gluu_action` LIKE 'oxd_config'")){
    $oxd_config = json_encode(array(
        "op_host"=> '',
        "oxd_host_ip" => '127.0.0.1',
        "oxd_host_port" =>8099,
        "admin_email" => $GLOBALS['current_user']->email1,
        "authorization_redirect_uri" => $base_url.'/gluu.php?gluu_login=Gluussos',
        "logout_redirect_uri" => $base_url.'/gluu_logout.php?gluu_login=Gluussos',
        "scope" => ["openid","profile","email","address","clientinfo","mobile_phone","phone"],
        "grant_types" =>["authorization_code"],
        "response_types" => ["code"],
        "application_type" => "web",
        "acr_values" => [],
    ));
    $result = $db->query("INSERT INTO gluu_table (gluu_action, gluu_value) VALUES ('oxd_config','$oxd_config')");
}
if($db->query("SELECT `gluu_value` FROM `gluu_table` WHERE `gluu_action` LIKE 'iconSpace'")){
    $iconSpace = '10';
    $db->query("INSERT INTO gluu_table (gluu_action, gluu_value) VALUES ('iconSpace','$iconSpace')");
}
if($db->query("SELECT `gluu_value` FROM `gluu_table` WHERE `gluu_action` LIKE 'iconCustomSize'")){
    $iconCustomSize = '50';
    $db->query("INSERT INTO gluu_table (gluu_action, gluu_value) VALUES ('iconCustomSize','$iconCustomSize')");
}
if($db->query("SELECT `gluu_value` FROM `gluu_table` WHERE `gluu_action` LIKE 'iconCustomWidth'")){
    $iconCustomWidth = '200';
    $db->query("INSERT INTO gluu_table (gluu_action, gluu_value) VALUES ('iconCustomWidth','$iconCustomWidth')");
}
if($db->query("SELECT `gluu_value` FROM `gluu_table` WHERE `gluu_action` LIKE 'iconCustomHeight'")){
    $iconCustomHeight = '35';
    $db->query("INSERT INTO gluu_table (gluu_action, gluu_value) VALUES ('iconCustomWidth','$iconCustomHeight')");
}
if($db->query("SELECT `gluu_value` FROM `gluu_table` WHERE `gluu_action` LIKE 'loginCustomTheme'")){
    $loginCustomTheme = 'default';
    $db->query("INSERT INTO gluu_table (gluu_action, gluu_value) VALUES ('loginCustomTheme','$iconCustomHeight')");
}
if($db->query("SELECT `gluu_value` FROM `gluu_table` WHERE `gluu_action` LIKE 'loginTheme'")){
    $loginTheme = 'oval';
    $db->query("INSERT INTO gluu_table (gluu_action, gluu_value) VALUES ('loginTheme','$loginTheme')");
}
if($db->query("SELECT `gluu_value` FROM `gluu_table` WHERE `gluu_action` LIKE 'iconCustomColor'")){
    $iconCustomColor = '#0000FF';
    $db->query("INSERT INTO gluu_table (gluu_action, gluu_value) VALUES ('iconCustomColor','$iconCustomColor')");
}
$get_scopes =                 json_decode($db->fetchRow($db->query("SELECT `gluu_value` FROM `gluu_table` WHERE `gluu_action` LIKE 'scopes'"))["gluu_value"],true);
$oxd_config =                 json_decode($db->fetchRow($db->query("SELECT `gluu_value` FROM `gluu_table` WHERE `gluu_action` LIKE 'oxd_config'"))["gluu_value"],true);
$custom_scripts =             json_decode($db->fetchRow($db->query("SELECT `gluu_value` FROM `gluu_table` WHERE `gluu_action` LIKE 'custom_scripts'"))["gluu_value"],true);
$iconSpace =                  $db->fetchRow($db->query("SELECT `gluu_value` FROM `gluu_table` WHERE `gluu_action` LIKE 'iconSpace'"))["gluu_value"];
$iconCustomSize =             $db->fetchRow($db->query("SELECT `gluu_value` FROM `gluu_table` WHERE `gluu_action` LIKE 'iconCustomSize'"))["gluu_value"];
$iconCustomWidth =            $db->fetchRow($db->query("SELECT `gluu_value` FROM `gluu_table` WHERE `gluu_action` LIKE 'iconCustomWidth'"))["gluu_value"];
$iconCustomHeight =           $db->fetchRow($db->query("SELECT `gluu_value` FROM `gluu_table` WHERE `gluu_action` LIKE 'iconCustomHeight'"))["gluu_value"];
$loginCustomTheme =           $db->fetchRow($db->query("SELECT `gluu_value` FROM `gluu_table` WHERE `gluu_action` LIKE 'loginCustomTheme'"))["gluu_value"];
$loginTheme =                 $db->fetchRow($db->query("SELECT `gluu_value` FROM `gluu_table` WHERE `gluu_action` LIKE 'loginTheme'"))["gluu_value"];
$iconCustomColor =            $db->fetchRow($db->query("SELECT `gluu_value` FROM `gluu_table` WHERE `gluu_action` LIKE 'iconCustomColor'"))["gluu_value"];

if($db->query("SELECT `gluu_value` FROM `gluu_table` WHERE `gluu_action` LIKE 'oxd_id'")){
    $oxd_id = $db->fetchRow($db->query("SELECT `gluu_value` FROM `gluu_table` WHERE `gluu_action` LIKE 'oxd_id'"))["gluu_value"];
}
?>
<link href="modules/Gluussos/GluuOxd_Openid/css/gluu-oxd-css.css" rel="stylesheet"/>
<link href="modules/Gluussos/GluuOxd_Openid/css/font-awesome.min.css" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="modules/Gluussos/GluuOxd_Openid/js/scope-custom-script.js"></script>
<script>
    var $m = jQuery.noConflict();
    $m(document).ready(function () {
        $oxd_id = "<?php echo $oxd_id; ?>";
        if ($oxd_id) {
            voiddisplay("#socialsharing");
            setactive('social-sharing-setup');
        } else {
            setactive('account_setup');
        }
        $m(".navbar a").click(function () {
            $id = $m(this).parent().attr('id');
            setactive($id);
            $href = $m(this).data('method');
            voiddisplay($href);
        });

        $m('#error-cancel').click(function () {
            $error = "";
            $m(".error-msg").css("display", "none");
        });
        $m('#success-cancel').click(function () {
            $success = "";
            $m(".success-msg").css("display", "none");
        });

        $m(".test").click(function () {
            $m(".mo2f_thumbnail").hide();
            $m("#twofactorselect").show();
            $m("#test_2factor").val($m(this).data("method"));
            $m("#mo2f_2factor_test_form").submit();
        });
    });
    function setactive($id) {
        $m(".navbar-tabs>li").removeClass("active");
        $m("#minisupport").show();
        $id = '#' + $id;
        $m($id).addClass("active");
    }
    function voiddisplay($href) {
        $m(".page").css("display", "none");
        $m($href).css("display", "block");
    }
    function mo2f_valid(f) {
        !(/^[a-zA-Z?,.\(\)\/@ 0-9]*$/).test(f.value) ? f.value = f.value.replace(/[^a-zA-Z?,.\(\)\/@ 0-9]/, '') : null;
    }
    jQuery(document).ready(function () {

        var tempHorSize = '<?php echo $iconCustomSize ?>';
        var tempHorTheme = '<?php echo $loginTheme ?>';
        var tempHorCustomTheme = '<?php echo $loginCustomTheme ?>';
        var tempHorCustomColor = '<?php echo $iconCustomColor ?>';
        var tempHorSpace = '<?php echo $iconSpace ?>';
        var tempHorHeight = '<?php echo $iconCustomHeight ?>';
        gluuOxLoginPreview(setSizeOfIcons(), tempHorTheme, tempHorCustomTheme, tempHorCustomColor, tempHorSpace, tempHorHeight);
        checkLoginButton();

    });
    function setLoginTheme() {
        return jQuery('input[name=gluuoxd_openid_login_theme]:checked', '#form-apps').val();
    }
    function setLoginCustomTheme() {
        return jQuery('input[name=gluuoxd_openid_login_custom_theme]:checked', '#form-apps').val();
    }
    function setSizeOfIcons() {
        if ((jQuery('input[name=gluuoxd_openid_login_theme]:checked', '#form-apps').val()) == 'longbutton') {
            return document.getElementById('gluuox_login_icon_width').value;
        } else {
            return document.getElementById('gluuox_login_icon_size').value;
        }
    }
    function gluuOxLoginPreview(t, r, l, p, n, h) {

        if (l == 'default') {
            if (r == 'longbutton') {
                var a = "btn-defaulttheme";
                jQuery("." + a).css("width", t + "px");
                if (h > 26) {
                    jQuery("." + a).css("height", "26px");
                    jQuery("." + a).css("padding-top", (h - 26) / 2 + "px");
                    jQuery("." + a).css("padding-bottom", (h - 26) / 2 + "px");
                } else {
                    jQuery("." + a).css("height", h + "px");
                    jQuery("." + a).css("padding-top", (h - 26) / 2 + "px");
                    jQuery("." + a).css("padding-bottom", (h - 26) / 2 + "px");
                }
                jQuery(".fa").css("padding-top", (h - 35) + "px");
                jQuery("." + a).css("margin-bottom", n + "px");
            } else {
                var a = "gluuox_login_icon_preview";
                jQuery("." + a).css("margin-left", n + "px");
                if (r == "circle") {
                    jQuery("." + a).css({height: t, width: t});
                    jQuery("." + a).css("borderRadius", "999px");
                } else if (r == "oval") {
                    jQuery("." + a).css("borderRadius", "5px");
                    jQuery("." + a).css({height: t, width: t});
                } else if (r == "square") {
                    jQuery("." + a).css("borderRadius", "0px");
                    jQuery("." + a).css({height: t, width: t});
                }
            }
        }
        else if (l == 'custom') {
            if (r == 'longbutton') {
                var a = "btn-customtheme";
                jQuery("." + a).css("width", (t) + "px");
                if (h > 26) {
                    jQuery("." + a).css("height", "26px");
                    jQuery("." + a).css("padding-top", (h - 26) / 2 + "px");
                    jQuery("." + a).css("padding-bottom", (h - 26) / 2 + "px");
                } else {
                    jQuery("." + a).css("height", h + "px");
                    jQuery("." + a).css("padding-top", (h - 26) / 2 + "px");
                    jQuery("." + a).css("padding-bottom", (h - 26) / 2 + "px");
                }
                jQuery("." + a).css("margin-bottom", n + "px");
                jQuery("." + a).css("background", p);
            } else {
                var a = "gluuOx_custom_login_icon_preview";
                jQuery("." + a).css({height: t - 8, width: t});
                jQuery("." + a).css("padding-top", "8px");
                jQuery("." + a).css("margin-left", n + "px");
                jQuery("." + a).css("background", p);

                if (r == "circle") {
                    jQuery("." + a).css("borderRadius", "999px");
                } else if (r == "oval") {
                    jQuery("." + a).css("borderRadius", "5px");
                } else if (r == "square") {
                    jQuery("." + a).css("borderRadius", "0px");
                }
                jQuery("." + a).css("font-size", (t - 16) + "px");
            }
        }
        previewLoginIcons();
    }
    function checkLoginButton() {
        if (document.getElementById('iconwithtext').checked) {
            if (setLoginCustomTheme() == 'default') {
                jQuery(".gluuox_login_icon_preview").hide();
                jQuery(".gluuOx_custom_login_icon_preview").hide();
                jQuery(".btn-customtheme").hide();
                jQuery(".btn-defaulttheme").show();
            } else if (setLoginCustomTheme() == 'custom') {
                jQuery(".gluuox_login_icon_preview").hide();
                jQuery(".gluuOx_custom_login_icon_preview").hide();
                jQuery(".btn-defaulttheme").hide();
                jQuery(".btn-customtheme").show();
            }
            jQuery("#commontheme").hide();
            jQuery(".longbuttontheme").show();
        }
        else {
            if (setLoginCustomTheme() == 'default') {
                jQuery(".gluuox_login_icon_preview").show();
                jQuery(".btn-defaulttheme").hide();
                jQuery(".btn-customtheme").hide();
                jQuery(".gluuOx_custom_login_icon_preview").hide();
            } else if (setLoginCustomTheme() == 'custom') {
                jQuery(".gluuox_login_icon_preview").hide();
                jQuery(".gluuOx_custom_login_icon_preview").show();
                jQuery(".btn-defaulttheme").hide();
                jQuery(".btn-customtheme").hide();
            }
            jQuery("#commontheme").show();
            jQuery(".longbuttontheme").hide();
        }

        previewLoginIcons();
    }
    function previewLoginIcons() {
        var flag = 0;
        <?php foreach($custom_scripts as $custom_script):?>
        if (document.getElementById('<?php echo $custom_script['value'];?>_enable').checked) {
            flag = 1;
            if (document.getElementById('gluuoxd_openid_login_default_radio').checked && !document.getElementById('iconwithtext').checked)
                jQuery("#gluuox_login_icon_preview_<?php echo $custom_script['value'];?>").show();
            if (document.getElementById('gluuoxd_openid_login_custom_radio').checked && !document.getElementById('iconwithtext').checked)
                jQuery("#gluuOx_custom_login_icon_preview_<?php echo $custom_script['value'];?>").show();
            if (document.getElementById('gluuoxd_openid_login_default_radio').checked && document.getElementById('iconwithtext').checked)
                jQuery("#gluuox_login_button_preview_<?php echo $custom_script['value'];?>").show();
            if (document.getElementById('gluuoxd_openid_login_custom_radio').checked && document.getElementById('iconwithtext').checked)
                jQuery("#gluuOx_custom_login_button_preview_<?php echo $custom_script['value'];?>").show();
        }
        else if (!document.getElementById('<?php echo $custom_script['value'];?>_enable').checked) {
            jQuery("#gluuox_login_icon_preview_<?php echo $custom_script['value'];?>").hide();
            jQuery("#gluuOx_custom_login_icon_preview_<?php echo $custom_script['value'];?>").hide();
            jQuery("#gluuox_login_button_preview_<?php echo $custom_script['value'];?>").hide();
            jQuery("#gluuOx_custom_login_button_preview_<?php echo $custom_script['value'];?>").hide();
        }
        <?php endforeach;?>
        if (flag) {
            jQuery("#no_apps_text").hide();
        } else {
            jQuery("#no_apps_text").show();
        }



    }
    var selectedApps = [];
    function setTheme() {
        return jQuery('input[name=gluuoxd_openid_share_theme]:checked', '#settings_form').val();
    }
    function setCustomTheme() {
        return jQuery('input[name=gluuoxd_openid_share_custom_theme]:checked', '#settings_form').val();
    }
    function gluuOxLoginSizeValidate(e) {
        var t = parseInt(e.value.trim());
        t > 60 ? e.value = 60 : 20 > t && (e.value = 20);
        reloadLoginPreview();
    }
    function gluuOxLoginSpaceValidate(e) {
        var t = parseInt(e.value.trim());
        t > 60 ? e.value = 60 : 0 > t && (e.value = 0);
        reloadLoginPreview();
    }
    function gluuOxLoginWidthValidate(e) {
        var t = parseInt(e.value.trim());
        t > 1000 ? e.value = 1000 : 140 > t && (e.value = 140)
        reloadLoginPreview();
    }
    function gluuOxLoginHeightValidate(e) {
        var t = parseInt(e.value.trim());
        t > 100 ? e.value = 100 : 10 > t && (e.value = 10)
        reloadLoginPreview();
    }
    function reloadLoginPreview() {
        if (setLoginTheme() == 'longbutton')
            gluuOxLoginPreview(document.getElementById('gluuox_login_icon_width').value, setLoginTheme(), setLoginCustomTheme(), document.getElementById('gluuox_login_icon_custom_color').value, document.getElementById('gluuox_login_icon_space').value,
                document.getElementById('gluuox_login_icon_height').value);
        else
            gluuOxLoginPreview(document.getElementById('gluuox_login_icon_size').value, setLoginTheme(), setLoginCustomTheme(), document.getElementById('gluuox_login_icon_custom_color').value, document.getElementById('gluuox_login_icon_space').value);
    }
</script>
<div class="heading"><h3>OpenID Connect SSO by Gluu </h3></div>
<div class="mo2f_container">
    <div class="container">
        <div id="messages">
            <?php if (!empty($_SESSION['message_error'])){ ?>
                <div class="mess_red_error">
                    <?php echo $_SESSION['message_error']; ?>
                </div>
                <?php unset($_SESSION['message_error']);} ?>
            <?php if (!empty($_SESSION['message_success'])) { ?>
                <div class="mess_green">
                    <?php echo $_SESSION['message_success']; ?>
                </div>
                <?php unset($_SESSION['message_success']);} ?>
        </div>
        <ul class="navbar navbar-tabs">
            <li id="account_setup"><a data-method="#accountsetup">General</a></li>
            <li id="social-sharing-setup"><a data-method="#socialsharing">OpenID Connect Configuration</a></li>
            <li id="social-login-setup"><a data-method="#sociallogin">SuiteCRM Configuration</a></li>
            <li id="help_trouble"><a data-method="#helptrouble">Help & Troubleshooting</a></li>
        </ul>
        <div class="container-page">
            <!-- General -->
            <?php if (!$oxd_id) { ?>
                <!-- General tab-->
                <div class="page" id="accountsetup">
                    <div class="mo2f_table_layout">
                        <form id="register_GluuOxd" name="f" method="post"
                              action="index.php?module=Gluussos&action=gluuPostData">
                            <input type="hidden" name="form_key" value="general_register_page"/>
                            <div class="login_GluuOxd">
                                <div class="mess_red">
                                    Please enter the details of your OpenID Connect Provider.
                                </div>
                                <br/>
                                <div><h3>Register your site with an OpenID Connect Provider</h3></div>
                                <hr>
                                <div class="mess_red">If you do not have an OpenID Connect provider, you may want to look at the Gluu Server (
                                    <a target="_blank" href="http://www.gluu.org/docs">Like SuiteCRM, there is a free open source Community Edition. For more information about Gluu Server support please visit <a target="_blank" href="http://www.gluu.org">our website.</a></a>)
                                </div>
                                <div class="mess_red">
                                    <h3>Instructions to Install oxd server</h3>
                                    <br><b>NOTE:</b> The oxd server should be installed on the same server as your SuiteCRM site. It is recommended that the oxd server listen only on the localhost interface, so only your local applications can reach its API's.
                                    <ol style="list-style:decimal !important; margin: 30px">
                                        <li>Extract and copy in your DMZ Server.</li>
                                        <li>Download the latest oxd-server package for Centos or Ubuntu. See
                                            <a target="_blank" href="http://gluu.org/docs-oxd">oxd docs</a> for more info.
                                        </li><li>If you are installing an .rpm or .deb, make sure you have Java in your server.
                                        </li><li>Edit <b>oxd-conf.json</b> in the <b>conf</b> directory to specify the port on which
                                            it will run, and specify the hostname of the OpenID Connect provider.</li>
                                        <li>Open the command line and navigate to the extracted folder in the <b>bin</b> directory.</li>
                                        <li>For Linux environment, run <b>sh oxd-start.sh &amp;</b></li>
                                        <li>For Windows environment, run <b>oxd-start.bat</b></li>
                                        <li>After the server starts, set the port number, your Gluu server url and your email in this page and click Next.</li>
                                    </ol>
                                </div>
                                <hr>
                                <div>
                                    <table class="table">
                                        <tr>
                                            <td><b><font color="#FF0000">*</font>Admin Email:</b></td>
                                            <td><input class="" type="email" name="loginemail" id="loginemail"
                                                       autofocus="true" required placeholder="person@example.com"
                                                       style="width:400px;"
                                                       value="<?php echo $oxd_config['admin_email']; ?>"/>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td><b><font color="#FF0000">*</font>Gluu Server URL:</b></td>
                                            <td><input class="" type="url" name="gluu_server_url" id="gluu_server_url"
                                                       autofocus="true" required placeholder="Enter Gluu Server URL."
                                                       style="width:400px;"
                                                       value=""/>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td><b><font color="#FF0000">*</font>Port number:</b></td>
                                            <td>
                                                <input class="" type="number" name="oxd_port" min="0" max="65535"
                                                       value="<?php echo $oxd_config['oxd_host_port']; ?>"
                                                       style="width:400px;" placeholder="Enter port number."/>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                                <br/>
                                <div><input type="submit" name="submit" value="Next" style="width: 120px" class=""/></div>
                                <br/>
                                <br/>
                            </div>
                        </form>
                    </div>
                </div>
            <?php } else{?>
                <div class="page" id="accountsetup">
                    <div>
                        <div>
                            <div class="about">
                                <h3 style="color: #45a8ff" class="sc"><img style=" height: 45px; margin-left: 20px;" src="modules/Gluussos/GluuOxd_Openid/images/icons/ox.png"/>&nbsp; server config</h3>
                            </div>
                        </div>
                        <div class="entry-edit" >
                            <div class="entry-edit-head">
                                <h4 class="icon-head head-edit-form fieldset-legend">OXD id</h4>
                            </div>
                            <div class="fieldset">
                                <div class="hor-scroll">
                                    <table class="form-list container">
                                        <tr class="wrapper-trr">
                                            <td class="value">
                                                <input style="width: 500px !important;" type="text" name="oxd_id" value="<?php echo $oxd_id; ?>" <?php echo 'disabled' ?>/>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <form action="index.php?module=Gluussos&action=gluuPostData" method="post">
                        <input type="hidden" name="form_key" value="general_oxd_id_reset"/>
                        <p><input style="width: 200px; background-color: red !important; cursor: pointer" type="submit" class="button button-primary " value="Reset configurations" name="resetButton"/></p>
                    </form>
                </div>
            <?php }?>
            <!--Scopes and custom scripts tab-->
            <div class="page" id="socialsharing">
                <?php if (!$oxd_id){ ?>
                    <div class="mess_red">
                        Please enter OXD configuration to continue.
                    </div><br/>
                <?php } ?>
                <div>
                    <form action="index.php?module=Gluussos&action=gluuPostData" method="post"
                          enctype="multipart/form-data">
                        <input type="hidden" name="form_key" value="openid_config_page"/>
                        <div>
                            <div>
                                <div class="about">
                                    <br/>
                                    <h3 style="color: #00aa00" class="sc"><img style="height: 45px; margin-left: 30px;" src="modules/Gluussos/GluuOxd_Openid/images/icons/gl.png"/> &nbsp; server config
                                    </h3>
                                </div>
                            </div>
                            <div class="entry-edit" >
                                <div class="entry-edit-head" style="background-color: #00aa00 !important;">
                                    <h4 class="icon-head head-edit-form fieldset-legend">All Scopes</h4>
                                </div>
                                <div class="fieldset">
                                    <div class="hor-scroll">
                                        <table class="form-list">
                                            <tr class="wrapper-trr">
                                                <?php foreach ($get_scopes as $scop) : ?>
                                                    <td class="value">
                                                        <?php if ($scop == 'openid'){?>
                                                            <input <?php if (!$oxd_id) echo ' disabled ' ?> type="hidden"  name="scope[]"  <?php if ($oxd_config && in_array($scop, $oxd_config['scope'])) {
                                                                echo " checked "; } ?> value="<?php echo $scop; ?>" />
                                                        <?php } ?>
                                                        <input <?php if (!$oxd_id) echo ' disabled ' ?> type="checkbox"  name="scope[]"  <?php if ($oxd_config && in_array($scop, $oxd_config['scope'])) {
                                                            echo " checked "; } ?> id="<?php echo $scop; ?>" value="<?php echo $scop; ?>" <?php if ($scop == 'openid') echo ' disabled '; ?> />
                                                        <label for="<?php echo $scop; ?>"><?php echo $scop; ?></label>
                                                    </td>
                                                <?php endforeach; ?>
                                            </tr>
                                        </table>
                                        <table class="form-list" style="text-align: center">
                                            <tr class="wrapper-tr" style="text-align: center">
                                                <th style="border: 1px solid #43ffdf; width: 70px;text-align: center"><h3>N</h3></th>
                                                <th style="border: 1px solid #43ffdf;width: 200px;text-align: center"><h3>Name</h3></th>
                                                <th style="border: 1px solid #43ffdf;width: 200px;text-align: center"><h3>Delete</h3></th>
                                            </tr>
                                            <?php
                                            $n = 0;
                                            foreach ($get_scopes as $scop) {
                                                $n++;
                                                ?>
                                                <tr class="wrapper-trr">
                                                    <td style="border: 1px solid #43ffdf; padding: 0px; width: 70px"><h3><?php echo $n; ?></h3></td>
                                                    <td style="border: 1px solid #43ffdf; padding: 0px; width: 200px"><h3><label for="<?php echo $scop; ?>"><?php echo $scop; ?></label></h3></td>
                                                    <td style="border: 1px solid #43ffdf; padding: 0px; width: 200px">
                                                        <?php if ($n == 1): ?>
                                                            <form></form>
                                                        <?php endif; ?>
                                                        <form
                                                            action="index.php?module=Gluussos&action=gluuPostData"
                                                            method="post">
                                                            <input type="hidden" name="form_key"
                                                                   value="openid_config_delete_scop"/>
                                                            <input type="hidden"
                                                                   value="<?php echo $scop; ?>"
                                                                   name="value_scope"/>
                                                            <?php if ($scop != 'openid'){ ?>
                                                                <input  style="width: 100px; background-color: red !important; cursor: pointer"
                                                                        type="submit"
                                                                        class="button button-primary " <?php if (!$oxd_id) echo 'disabled' ?>
                                                                        value="Delete" name="delete_scop"/>
                                                            <?php }  ?>
                                                        </form>
                                                    </td>
                                                </tr>
                                                <?php
                                            }
                                            ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="entry-edit">
                                <div class="entry-edit-head" style="background-color: #00aa00 !important;">
                                    <h4 class="icon-head head-edit-form fieldset-legend">Add scopes</h4>
                                </div>
                                <div class="fieldset">
                                    <input type="button" id="adding" class="button button-primary button-large add" style="width: 100px" value="Add scopes"/>
                                    <div class="hor-scroll">
                                        <table class="form-list5 container">
                                            <tr class="wrapper-tr">
                                                <td class="value">
                                                    <input type="text" placeholder="Input scope name" name="scope_name[]"/>
                                                </td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="entry-edit" >
                                <div class="entry-edit-head" style="background-color: #00aa00 !important;">
                                    <h4 class="icon-head head-edit-form fieldset-legend">All custom scripts</h4>
                                </div>
                                <div class="fieldset">
                                    <div class="hor-scroll">
                                        <h3>Manage Authentication</h3>
                                        <p>An OpenID Connect Provider (OP) like the Gluu Server may provide many different work flows for
                                            authentication. For example, an OP may offer password authentication, token authentication, social
                                            authentication, biometric authentication, and other different mechanisms. Offering a lot of different
                                            types of authentication enables an OP to offer the most convenient, secure, and affordable option to
                                            identify a person, depending on the need to mitigate risk, and the sensors and inputs available on the
                                            device that the person is using.
                                        </p>
                                        <p>
                                            The OP enables a client (like a SuiteCRM site), to signal which type of authentication should be
                                            used. The client can register a
                                            <a target="_blank" href="http://openid.net/specs/openid-connect-registration-1_0.html#ClientMetadata">default_acr_value</a>
                                            or during the authentication process, a client may request a specific type of authentication using the
                                            <a target="_blank" href="http://openid.net/specs/openid-connect-core-1_0.html#AuthRequest">acr_values</a> parameter.
                                            This is the mechanism that the Gluu SSO module uses: each login icon corresponds to a acr request value.
                                            For example, and acr may tell the OpenID Connect to use Facebook, Google or even plain old password authentication.
                                            The nice thing about this approach is that your applications (like SuiteCRM) don't have
                                            to implement the business logic for social login--it's handled by the OpenID Connect Provider.
                                        </p>
                                        <p>
                                            If you are using the Gluu Server as your OP, you'll notice that in the Manage Custom Scripts
                                            tab of oxTrust (the Gluu Server admin interface), each authentication script has a name.
                                            This name corresponds to the acr value.  The default acr for password authentication is set in
                                            the
                                            <a target="_blank" href="https://www.gluu.org/docs/admin-guide/configuration/#manage-authentication">LDAP Authentication</a>,
                                            section--look for the "Name" field. Likewise, each custom script has a "Name", for example see the
                                            <a target="_blank" href="https://www.gluu.org/docs/admin-guide/configuration/#manage-custom-scripts">Manage Custom Scripts</a> section.
                                        </p>
                                        <table style="width:100%;display: table;">
                                            <tbody>
                                            <tr>
                                                <?php
                                                foreach ($custom_scripts as $custom_script) {
                                                    ?>
                                                    <td style="width:25%">
                                                        <input type="checkbox" <?php if (!$oxd_id) echo 'disabled'; ?>
                                                               id="<?php echo $custom_script['value']; ?>_enable"
                                                               class="app_enable"
                                                               name="gluuoxd_openid_<?php echo $custom_script['value']; ?>_enable"
                                                               value="1"
                                                               onchange="previewLoginIcons();" <?php if ($db->fetchRow($db->query("SELECT `gluu_value` FROM `gluu_table` WHERE `gluu_action` LIKE '".$custom_script['value']."Enable'"))['gluu_value']) echo "checked"; ?> /><b><?php echo $custom_script['name']; ?></b>
                                                    </td>
                                                    <?php
                                                }
                                                ?>
                                            </tr>
                                            <tr style="display: none;">
                                            </tr>
                                            </tbody>
                                        </table>
                                        <table class="form-list" style="text-align: center">
                                            <tr class="wrapper-tr" style="text-align: center">
                                                <th style="border: 1px solid #43ffdf; width: 70px;text-align: center"><h3>N</h3></th>
                                                <th style="border: 1px solid #43ffdf;width: 200px;text-align: center"><h3>Display Name</h3></th>
                                                <th style="border: 1px solid #43ffdf;width: 200px;text-align: center"><h3>ACR Value</h3></th>
                                                <th style="border: 1px solid #43ffdf;width: 200px;text-align: center"><h3>Image</h3></th>
                                                <th style="border: 1px solid #43ffdf;width: 200px;text-align: center"><h3>Delete</h3></th>
                                            </tr>
                                            <?php
                                            $n = 0;
                                            foreach ($custom_scripts as $custom_script) {
                                                $n++;
                                                ?>
                                                <tr class="wrapper-trr">
                                                    <td style="border: 1px solid #43ffdf; padding: 0px; width: 70px"><h3><?php echo $n; ?></h3></td>
                                                    <td style="border: 1px solid #43ffdf; padding: 0px; width: 200px"><h3><?php echo $custom_script['name']; ?></h3></td>
                                                    <td style="border: 1px solid #43ffdf; padding: 0px; width: 200px"><h3><?php echo $custom_script['value']; ?></h3></td>
                                                    <td style="border: 1px solid #43ffdf; padding: 0px; width: 200px"><img src="<?php echo $custom_script['image']; ?>" width="40px" height="40px"/></td>
                                                    <td style="border: 1px solid #43ffdf; padding: 0px; width: 200px">
                                                        <?php if ($n == 1): ?>
                                                            <form></form>
                                                        <?php endif; ?>
                                                        <form
                                                            action="index.php?module=Gluussos&action=gluuPostData"
                                                            method="post">
                                                            <input type="hidden" name="form_key"
                                                                   value="openid_config_delete_custom_scripts"/>
                                                            <input type="hidden"
                                                                   value="<?php echo $custom_script['value']; ?>"
                                                                   name="value_script"/>
                                                            <input
                                                                style="width: 100px; background-color: red !important; cursor: pointer"
                                                                type="submit"
                                                                class="button button-primary " <?php if (!$oxd_id) echo 'disabled' ?>
                                                                value="Delete" name="delete_config"/>
                                                        </form>
                                                    </td>
                                                </tr>
                                                <?php
                                            }
                                            ?>
                                        </table>
                                    </div>
                                </div>
                                <br/>
                                <div class="entry-edit-head" style="background-color: #00aa00 !important;">
                                    <h4 class="icon-head head-edit-form fieldset-legend">Add multiple custom scripts</h4>
                                    <br/>
                                    <p style="color:#cc0b07; font-style: italic; font-weight: bold;font-size: larger"> Both fields are required</p>
                                </div>
                                <div class="fieldset">
                                    <div class="hor-scroll">
                                        <input type="hidden" name="count_scripts" value="1" id="count_scripts">
                                        <input type="button" class="button button-primary button-large " style="width: 100px" id="adder" value="Add acr"/>
                                        <table class="form-list1 container">
                                            <tr class="count_scripts wrapper-trr">
                                                <td class="value">
                                                    <input style='width: 200px !important;' type="text" placeholder="Display name (example Google+)" name="name_in_site_1"/>
                                                </td>
                                                <td class="value">
                                                    <input style='width: 270px !important;' type="text" placeholder="ACR Value (script name in the Gluu Server)" name="name_in_gluu_1"/>
                                                </td>
                                                <td class="value">
                                                    <input type="file" accept="image/png" name="images_1"/>
                                                </td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div>
                            <input class="set_oxd_config" style="width: 100px" type="submit" class="button button-primary button-large" <?php if (!$oxd_id) echo 'disabled' ?> value="Save" name="set_oxd_config"/>
                            <br/>
                        </div>
                    </form>
                </div>
            </div>
            <!--Gluu and social login config tab-->
            <div class="page" id="sociallogin">
                <?php if (!$oxd_id){ ?>
                    <div class="mess_red">
                        Please enter OXD configuration to continue.
                    </div><br/>
                <?php } ?>

                <form id="form-apps" name="form-apps" method="post"
                      action="index.php?module=Gluussos&action=gluuPostData" enctype="multipart/form-data">
                    <input type="hidden" name="form_key" value="sugar_crm_config_page"/>
                    <div class="mo2f_table_layout">
                        <input <?php if (!$oxd_id) echo 'disabled'; ?> type="submit" name="submit" value="Save" style="width:100px;margin-right:2%" class="button button-primary button-large">
                    </div>
                    <div id="twofactor_list" class="mo2f_table_layout">
                        <h3>Gluu login config </h3>
                        <hr>
                        <p style="font-size:14px">Customize your login icons using a range of shapes and sizes. You can choose different places to display these icons and also customize redirect url after login.</p>
                        <br/>
                        <hr>
                        <br>
                        <h3>Customize Login Icons</h3>
                        <p>Customize shape, theme and size of the login icons</p>
                        <table style="width:100%;display: table;">
                            <tbody>
                            <tr>
                                <td>
                                    <b>Shape</b>
                                    <b style="margin-left:130px; display: none">Theme</b>
                                    <b style="margin-left:130px;">Space between Icons</b>
                                    <b style="margin-left:86px;">Size of Icons</b>
                                </td>
                            </tr>
                            <tr>
                                <td class="gluuoxd_openid_table_td_checkbox">
                                    <input type="radio" <?php if (!$oxd_id) echo 'disabled'; ?>
                                           name="gluuoxd_openid_login_theme" value="circle"
                                           onclick="checkLoginButton();gluuOxLoginPreview(document.getElementById('gluuox_login_icon_size').value ,'circle',setLoginCustomTheme(),document.getElementById('gluuox_login_icon_custom_color').value,document.getElementById('gluuox_login_icon_space').value)"
                                           style="width: auto;" checked>Round
                            <span style="margin-left:106px; display: none">
                                <input type="radio" <?php if (!$oxd_id) echo 'disabled'; ?>
                                       id="gluuoxd_openid_login_default_radio" name="gluuoxd_openid_login_custom_theme"
                                       value="default"
                                       onclick="checkLoginButton();gluuOxLoginPreview(setSizeOfIcons(), setLoginTheme(),'default',document.getElementById('gluuox_login_icon_custom_color').value,document.getElementById('gluuox_login_icon_space').value,document.getElementById('gluuox_login_icon_height').value)"
                                       checked>Default
                            </span>
                            <span style="margin-left:111px;">
                                    <input
                                        style="width:50px" <?php if (!$oxd_id) echo ' disabled '; ?>
                                        onkeyup="gluuOxLoginSpaceValidate(this)" id="gluuox_login_icon_space"
                                        name="gluuox_login_icon_space" type="text" value="<?php echo $iconSpace; ?>" />
                                    <input
                                        id="gluuox_login_space_plus" <?php if (!$oxd_id) echo 'disabled'; ?> <?php if (!$oxd_id) echo 'disabled'; ?> <?php if (!$oxd_id) echo 'disabled'; ?>
                                        type="button" value="+"
                                        onmouseup="document.getElementById('gluuox_login_icon_space').value=parseInt(document.getElementById('gluuox_login_icon_space').value)+1;gluuOxLoginPreview(setSizeOfIcons() ,setLoginTheme(),setLoginCustomTheme(),document.getElementById('gluuox_login_icon_custom_color').value,document.getElementById('gluuox_login_icon_space').value)">
                                    <input
                                        id="gluuox_login_space_minus" <?php if (!$oxd_id) echo 'disabled'; ?> <?php if (!$oxd_id) echo 'disabled'; ?>
                                        type="button" value="-"
                                        onmouseup="document.getElementById('gluuox_login_icon_space').value=parseInt(document.getElementById('gluuox_login_icon_space').value)-1;gluuOxLoginPreview(setSizeOfIcons()  ,setLoginTheme(),setLoginCustomTheme(),document.getElementById('gluuox_login_icon_custom_color').value,document.getElementById('gluuox_login_icon_space').value)">
                            </span>
                            <span id="commontheme" style="margin-left:95px">
                                <input style="width:50px " <?php if (!$oxd_id) echo 'disabled'; ?> id="gluuox_login_icon_size"
                                       onkeyup="gluuOxLoginSizeValidate(this)" name="gluuox_login_icon_custom_size" type="text"
                                       value="<?php if ($iconCustomSize) echo $iconCustomSize; else echo '35'; ?>">
                                <input id="gluuox_login_size_plus" <?php if (!$oxd_id) echo 'disabled'; ?> type="button" value="+"
                                       onmouseup="document.getElementById('gluuox_login_icon_size').value=parseInt(document.getElementById('gluuox_login_icon_size').value)+1;gluuOxLoginPreview(document.getElementById('gluuox_login_icon_size').value ,setLoginTheme(),setLoginCustomTheme(),document.getElementById('gluuox_login_icon_custom_color').value,document.getElementById('gluuox_login_icon_space').value)">
                                <input id="gluuox_login_size_minus" <?php if (!$oxd_id) echo 'disabled'; ?> type="button" value="-"
                                       onmouseup="document.getElementById('gluuox_login_icon_size').value=parseInt(document.getElementById('gluuox_login_icon_size').value)-1;gluuOxLoginPreview(document.getElementById('gluuox_login_icon_size').value ,setLoginTheme(),setLoginCustomTheme(),document.getElementById('gluuox_login_icon_custom_color').value,document.getElementById('gluuox_login_icon_space').value)">
                            </span>
                            <span style="margin-left: 95px; display: none;" class="longbuttontheme">Width:&nbsp;
                                <input style="width:50px" <?php if (!$oxd_id) echo 'disabled'; ?> id="gluuox_login_icon_width"
                                       onkeyup="gluuOxLoginWidthValidate(this)" name="gluuox_login_icon_custom_width" type="text"
                                       value="<?php echo $iconCustomWidth; ?>">
                                <input id="gluuox_login_width_plus" <?php if (!$oxd_id) echo 'disabled'; ?> type="button" value="+"
                                       onmouseup="document.getElementById('gluuox_login_icon_width').value=parseInt(document.getElementById('gluuox_login_icon_width').value)+1;gluuOxLoginPreview(document.getElementById('gluuox_login_icon_width').value ,setLoginTheme(),setLoginCustomTheme(),document.getElementById('gluuox_login_icon_custom_color').value,document.getElementById('gluuox_login_icon_space').value,document.getElementById('gluuox_login_icon_height').value)">
                                <input id="gluuox_login_width_minus" <?php if (!$oxd_id) echo 'disabled'; ?> type="button" value="-"
                                       onmouseup="document.getElementById('gluuox_login_icon_width').value=parseInt(document.getElementById('gluuox_login_icon_width').value)-1;gluuOxLoginPreview(document.getElementById('gluuox_login_icon_width').value ,setLoginTheme(),setLoginCustomTheme(),document.getElementById('gluuox_login_icon_custom_color').value,document.getElementById('gluuox_login_icon_space').value,document.getElementById('gluuox_login_icon_height').value)">
                            </span>
                                </td>
                            </tr>
                            <tr>
                                <td class="gluuoxd_openid_table_td_checkbox">
                                    <input type="radio"
                                           name="gluuoxd_openid_login_theme" <?php if (!$oxd_id) echo 'disabled'; ?>
                                           value="oval"
                                           onclick="checkLoginButton();gluuOxLoginPreview(document.getElementById('gluuox_login_icon_size').value,'oval',setLoginCustomTheme(),document.getElementById('gluuox_login_icon_custom_color').value,document.getElementById('gluuox_login_icon_space').value,document.getElementById('gluuox_login_icon_size').value )"
                                           style="width: auto;" <?php if ($loginTheme == 'oval') echo "checked"; ?>>Rounded Edges
                        <span style="margin-left:50px; display: none">
                                <input type="radio"
                                       <?php if (!$oxd_id) echo 'disabled'; ?>id="gluuoxd_openid_login_custom_radio"
                                       name="gluuoxd_openid_login_custom_theme" value="custom"
                                       onclick="checkLoginButton();gluuOxLoginPreview(setSizeOfIcons(), setLoginTheme(),'custom',document.getElementById('gluuox_login_icon_custom_color').value,document.getElementById('gluuox_login_icon_space').value,document.getElementById('gluuox_login_icon_height').value)"
                                    <?php if ($loginCustomTheme == 'custom') echo "checked"; ?> >Custom Background*
                                </span>
                            <span style="margin-left: 256px; display: none;" class="longbuttontheme">Height:
                            <input style="width:50px" <?php if (!$oxd_id) echo 'disabled'; ?> id="gluuox_login_icon_height"
                                   onkeyup="gluuOxLoginHeightValidate(this)" name="gluuox_login_icon_custom_height" type="text"
                                   value="<?php if ($iconCustomHeight) echo $iconCustomHeight; else echo '35'; ?>">
                            <input id="gluuox_login_height_plus" <?php if (!$oxd_id) echo 'disabled'; ?> type="button" value="+"
                                   onmouseup="document.getElementById('gluuox_login_icon_height').value=parseInt(document.getElementById('gluuox_login_icon_height').value)+1;gluuOxLoginPreview(document.getElementById('gluuox_login_icon_width').value,setLoginTheme(),setLoginCustomTheme(),document.getElementById('gluuox_login_icon_custom_color').value,document.getElementById('gluuox_login_icon_space').value,document.getElementById('gluuox_login_icon_height').value)">
                            <input id="gluuox_login_height_minus" <?php if (!$oxd_id) echo 'disabled'; ?> type="button" value="-"
                                   onmouseup="document.getElementById('gluuox_login_icon_height').value=parseInt(document.getElementById('gluuox_login_icon_height').value)-1;gluuOxLoginPreview(document.getElementById('gluuox_login_icon_width').value,setLoginTheme(),setLoginCustomTheme(),document.getElementById('gluuox_login_icon_custom_color').value,document.getElementById('gluuox_login_icon_space').value,document.getElementById('gluuox_login_icon_height').value)">
                        </span>
                                </td>
                            </tr>
                            <tr>
                                <td class="gluuoxd_openid_table_td_checkbox">
                                    <input type="radio" <?php if (!$oxd_id) echo 'disabled'; ?>
                                           name="gluuoxd_openid_login_theme" value="square"
                                           onclick="checkLoginButton();gluuOxLoginPreview(document.getElementById('gluuox_login_icon_size').value ,'square',setLoginCustomTheme(),document.getElementById('gluuox_login_icon_custom_color').value,document.getElementById('gluuox_login_icon_space').value,document.getElementById('gluuox_login_icon_size').value )"
                                           style="width: auto;" <?php if ($loginTheme == 'square') echo "checked"; ?>>Square
                                    <span style="margin-left:113px; display: none">
                                        <input type="color" <?php if (!$oxd_id) echo 'disabled'; ?>
                                               name="gluuox_login_icon_custom_color" id="gluuox_login_icon_custom_color"
                                               value="<?php echo $iconCustomColor; ?>"
                                               onchange="gluuOxLoginPreview(setSizeOfIcons(), setLoginTheme(),'custom',document.getElementById('gluuox_login_icon_custom_color').value,document.getElementById('gluuox_login_icon_space').value)">
                                    </span>
                                </td>
                            </tr>
                            <tr style="display: none">
                                <td class="gluuoxd_openid_table_td_checkbox">
                                    <input
                                        type="radio" <?php if (!$oxd_id) echo 'disabled'; ?> <?php if (!$oxd_id) echo 'disabled'; ?>
                                        id="iconwithtext" name="gluuoxd_openid_login_theme" value="longbutton"
                                        onclick="checkLoginButton();gluuOxLoginPreview(document.getElementById('gluuox_login_icon_width').value ,'longbutton',setLoginCustomTheme(),document.getElementById('gluuox_login_icon_custom_color').value,document.getElementById('gluuox_login_icon_space').value,document.getElementById('gluuox_login_icon_height').value)"
                                        style="width: auto;" <?php if ($loginTheme == 'longbutton') echo "checked"; ?>>Long
                                    Button with Text
                                </td>
                            </tr>
                            </tbody>
                        </table>
                        <br>
                        <h3>Preview : </h3>
                        <span hidden id="no_apps_text">No apps selected</span>
                        <div>
                            <?php foreach ($custom_scripts as $custom_script): ?>
                                <img class="gluuox_login_icon_preview"
                                     id="gluuox_login_icon_preview_<?php echo $custom_script['value']; ?>"
                                     src="<?php echo $custom_script['image']; ?>"/>
                            <?php endforeach; ?>
                        </div>
                        <div>
                            <?php foreach ($custom_scripts as $custom_script): ?>
                                <a id="gluuox_login_button_preview_<?php echo $custom_script['value']; ?>"
                                   class="btn btn-block btn-defaulttheme btn-social btn-<?php echo $custom_script['value']; ?> btn-custom-size"
                                   style="width: <?php echo $iconCustomWidth; ?>px; height:<?php echo $iconCustomHeight; ?>px; padding-top: 6px; padding-bottom: 6px; margin-bottom: <?php echo $iconSpace . 'px'; ?>">
                                    <i class="fa fa-<?php echo $custom_script['value']; ?>-plus"
                                       style="padding-top: 0px;"></i>Login with <?php echo $custom_script['name']; ?>
                                </a>
                            <?php endforeach; ?>
                        </div>
                        <div>
                            <?php foreach ($custom_scripts as $custom_script): ?>
                                <i class="gluuOx_custom_login_icon_preview fa fa-<?php echo $custom_script['value']; ?>-plus"
                                   id="gluuOx_custom_login_icon_preview_<?php echo $custom_script['value']; ?>"
                                   style="color:#ffffff;text-align:center;margin-top:5px;"></i>
                            <?php endforeach; ?>
                        </div>
                        <div>
                            <?php foreach ($custom_scripts as $custom_script): ?>
                                <a id="gluuOx_custom_login_button_preview_<?php echo $custom_script['value']; ?>"
                                   class="btn btn-block btn-customtheme btn-social   btn-custom-size"
                                   style="width:<?php echo $iconCustomWidth; ?>px;height:<?php echo $iconCustomHeight; ?>px;padding-top: 6px;padding-bottom: 6px;margin-bottom:<?php echo $iconSpace; ?>px;background:<?php echo $iconCustomColor; ?>;">
                                    <i class="fa fa-<?php echo $custom_script['value']; ?>-plus"></i>Login
                                    with <?php echo $custom_script['name']; ?></a>
                            <?php endforeach; ?>
                        </div>
                        <br><br>
                    </div>
                </form>
            </div>
            <style>
                #helptrouble h1, #helptrouble h2{
                    font-size: 25px;
                    font-weight: bold;
                    color: black;
                }
            </style>
            <!-- Help & Troubleshooting tab-->
            <div class="page" id="helptrouble">

                <h1><a id="SuiteCRM_GLUU_SSO_module_0"></a>SuiteCRM OpenID Connect Single Sign-On (SSO) Module by Gluu</h1>
                <p><img src="https://raw.githubusercontent.com/GluuFederation/gluu-sso-SuiteCRM-module/master/plugin.jpg" alt="image"></p>
                <p>Gluu's SuiteCRM OpenID Connect Single Sign On (SSO) Module will enable you to authenticate users against any standard OpenID Connect Provider (OP). If you don't already have an OP you can [deploy the free open source Gluu Server](https://gluu.org/docs/deployment).</p>

                <h2><a id="Step_1_Install_Gluuserver_13"></a>Step 1. Install</h2>
                <p>In order to use the SuiteCRM Module, you will need to have deployed a standard OP like the Gluu Server and the oxd Server.</p>
                <p><a target="_blank" href="https://www.gluu.org/docs/deployment/">Gluu-server installation gide</a>.</p>
                <p><a target="_blank" href="https://oxd.gluu.org/docs/oxdserver/install/">oxd server installation gide</a>.</p>
                <h2><a id="Step_6_General_73"></a>Step 4. General</h2>
                <p><img src="https://raw.githubusercontent.com/GluuFederation/gluu-sso-SuiteCRM-module/master/docu/15.png" alt="General"></p>
                <ol>
                    <li>Admin Email: please add your or admin email address for registrating site in Gluu server.</li>
                    <li>Gluu Server URL: please enter Gluu Server URL.</li>
                    <li>Port number: choose that port which is using oxd-server (see in oxd-server/conf/oxd-conf.json file).</li>
                    <li>Click <code>Next</code> to continue.</li>
                </ol>
                <p>If You are successfully registered in gluu server, you will see bottom page.</p>
                <p><img src="https://raw.githubusercontent.com/GluuFederation/gluu-sso-SuiteCRM-module/master/docu/d7.png" alt="oxD_id"></p>
                <p>To make sure everything is configured properly, login to your Gluu Server and navigate to the OpenID Connect > Clients page. Search for your `oxd id`.</p>
                <h2><a id="Step_8_OpenID_Connect_Configuration_89"></a>Step 5. OpenID Connect Configuration</h2>
                <h3><a id="Scopes_93"></a>Scopes.</h3>
                <p>Scopes are groups of user attributes that are sent from your OP (in this case, the Gluu Server) to the application during login and enrollment. You can view all available scopes in your Gluu Server by navigating to the OpenID Connect > Scopes intefrace..</p>
                <p>In the Module interface you can enable, disable and delete scopes. You can also add new scopes. If/when you add new scopes via the module, be sure to also add the same scopes in your gluu server.
                    <img src="https://raw.githubusercontent.com/GluuFederation/gluu-sso-SuiteCRM-module/master/docu/d9.png" alt="Scopes1"></p>
                <h3><a id="Custom_scripts_104"></a>Custom scripts.</h3>
                <p>To specify the desired authentication mechanism navigate to the Configuration > Manage Custom Scripts menu in your Gluu Server. From there you can enable one of the out-of-the-box authentication mechanisms, such as password, U2F device (like yubikey), or mobile authentication. You can learn more about the Gluu Server authentication capabilities in the [docs](https://gluu.org/docs/multi-factor/intro/).</p>
                <p><img src="https://raw.githubusercontent.com/GluuFederation/gluu-sso-SuiteCRM-module/master/docu/d10.png" alt="Customscripts"></p>

                <h3><a id="Pay_attention_to_that_111"></a>Note:</h3>
                <ol>
                    <li>- The authentication mechanism specified in your SuiteCRM module page must match the authentication mechanism specified in your Gluu Server.</li>
                    <li>- After saving the authentication mechanism in your Gluu Server, it will be displayed in the SuiteCRM Module configuration page too.</li>
                    <li>- If / when you create a new custom script, both fields are required.</li>
                </ol>
                <h2><a id="Step_9_SuiteCRM_Configuration_117"></a>Step 6. SuiteCRM Configuration</h2>
                <h3><a id="Customize_Login_Icons_119"></a>Customize Login Icons</h3>
                <p>If custom scripts are not enabled, nothing will be showed. Customize shape, space between icons and size of the login icons.</p>
                <p><img src="https://raw.githubusercontent.com/GluuFederation/gluu-sso-SuiteCRM-module/master/docu/d11.png" alt="SuiteCRMConfiguration"></p>
                <h2><a id="Step_10_Show_icons_in_frontend_126"></a>Step 7. Show icons in frontend</h2>
                <h3><a id="Customize_Login_Icons_121"></a>Once you've configured all the options, you should see your supported authentication mechanisms on your default SuiteCRM login page like the screenshot below</h3>
                <p><img src="https://raw.githubusercontent.com/GluuFederation/gluu-sso-SuiteCRM-module/master/docu/d12.png" alt="frontend"></p>

            </div>
        </div>
        <!-- END of Container Page -->
    </div>
    <!-- END of Container -->
</div>
